
INSTALL_DIR=$(pwd)/_install

mkdir build
cd build

BD=Release

cmake -GNinja -DCMAKE_BUILD_TYPE=${BD} -DGTEST_HAS_ABSL=ON -DCMAKE_INSTALL_PREFIX=${INSTALL_DIR} ..
ninja -j12
ninja install
